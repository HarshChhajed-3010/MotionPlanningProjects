# Mailing Lists {#mailingLists}

- Email ompl-users@lists.sourceforge.net to write to the OMPL discussion mailing list. You can subscribe to the list and see an archive of previous messages [here](https://lists.sourceforge.net/lists/listinfo/ompl-users).
- Email ompl-devel@lists.sourceforge.net to contact the core developers. Please use this list only if you have questions that you feel are not appropriate for the ompl-users mailing list.
